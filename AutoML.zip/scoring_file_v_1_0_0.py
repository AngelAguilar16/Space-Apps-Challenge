# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import json
import logging
import os
import pickle
import numpy as np
import pandas as pd
import joblib

import azureml.automl.core
from azureml.automl.core.shared import logging_utilities, log_server
from azureml.telemetry import INSTRUMENTATION_KEY

from inference_schema.schema_decorators import input_schema, output_schema
from inference_schema.parameter_types.numpy_parameter_type import NumpyParameterType
from inference_schema.parameter_types.pandas_parameter_type import PandasParameterType


input_sample = pd.DataFrame({"FID": pd.Series(["example_value"], dtype="object"), "Survey_Type": pd.Series(["example_value"], dtype="object"), "Organization": pd.Series(["example_value"], dtype="object"), "Date": pd.Series(["example_value"], dtype="object"), "Survey_Year": pd.Series(["example_value"], dtype="object"), "Country": pd.Series(["example_value"], dtype="object"), "State": pd.Series(["example_value"], dtype="object"), "County": pd.Series(["example_value"], dtype="object"), "Survey_ID": pd.Series([0.0], dtype="float64"), "MDMAP_ID__": pd.Series([0.0], dtype="float64"), "Shoreline_Name": pd.Series(["example_value"], dtype="object"), "Latitude_Start": pd.Series([0.0], dtype="float64"), "Longitude_Start": pd.Series([0.0], dtype="float64"), "Latitude_End": pd.Series([0.0], dtype="float64"), "Longitude_End": pd.Series([0.0], dtype="float64"), "Slope": pd.Series([0.0], dtype="float64"), "Width": pd.Series([0.0], dtype="float64"), "Length": pd.Series([0.0], dtype="float64"), "Start_Time": pd.Series(["example_value"], dtype="object"), "End_Time": pd.Series(["example_value"], dtype="object"), "Time_of_Low_Tide": pd.Series(["example_value"], dtype="object"), "Database_Season": pd.Series(["example_value"], dtype="object"), "Season": pd.Series(["example_value"], dtype="object"), "Date_of_Previous_Survey": pd.Series(["example_value"], dtype="object"), "Days_since_last_survey": pd.Series([0.0], dtype="float64"), "Storm_Activity": pd.Series(["example_value"], dtype="object"), "Current_Weather": pd.Series(["example_value"], dtype="object"), "Number_of_Persons_Assisting": pd.Series([0.0], dtype="float64"), "Large_Items_": pd.Series(["example_value"], dtype="object"), "Debris_Behind_Back_Barrier_": pd.Series(["example_value"], dtype="object"), "Datasheet_Version": pd.Series([0.0], dtype="float64"), "Notes": pd.Series(["example_value"], dtype="object"), "Photos": pd.Series(["example_value"], dtype="object"), "Plastic": pd.Series([0.0], dtype="float64"), "Plastic___Flux": pd.Series([0.0], dtype="float64"), "Hard_Plastic_Fragments": pd.Series([0.0], dtype="float64"), "Hard_Plastic_Fragments___Flux": pd.Series([0.0], dtype="float64"), "Foamed_Plastic_Fragments": pd.Series([0.0], dtype="float64"), "Foamed_Plastic_Fragments___Flux": pd.Series([0.0], dtype="float64"), "Filmed_Plastic_Fragments": pd.Series([0.0], dtype="float64"), "Filmed_Plastic_Fragments___Flux": pd.Series([0.0], dtype="float64"), "Food_Wrappers": pd.Series([0.0], dtype="float64"), "Food_Wrappers___Flux": pd.Series([0.0], dtype="float64"), "Plastic_Beverage_Bottles": pd.Series([0.0], dtype="float64"), "Plastic_Beverage_Bottles___Flux": pd.Series([0.0], dtype="float64"), "Other_Jugs_Containers": pd.Series([0.0], dtype="float64"), "Other_Jugs_Containers___Flux": pd.Series([0.0], dtype="float64"), "Bottle_Container_Caps": pd.Series([0.0], dtype="float64"), "Bottle_Container_Caps___Flux": pd.Series([0.0], dtype="float64"), "Cigar_Tips": pd.Series([0.0], dtype="float64"), "Cigar_Tips___Flux": pd.Series([0.0], dtype="float64"), "Cigarettes": pd.Series([0.0], dtype="float64"), "Cigarettes___Flux": pd.Series([0.0], dtype="float64"), "Disposable_Cigarette_Lighters": pd.Series([0.0], dtype="float64"), "Disposable_Cigarette_Lighters__": pd.Series([0.0], dtype="float64"), "F6_Pack_Rings": pd.Series([0.0], dtype="float64"), "F6_Pack_Rings___Flux": pd.Series([0.0], dtype="float64"), "Bags": pd.Series([0.0], dtype="float64"), "Bags___Flux": pd.Series([0.0], dtype="float64"), "Plastic_Rope_Net": pd.Series([0.0], dtype="float64"), "Plastic_Rope_Net___Flux": pd.Series([0.0], dtype="float64"), "Buoys___Floats": pd.Series([0.0], dtype="float64"), "Buoys___Floats___Flux": pd.Series([0.0], dtype="float64"), "Fishing_Lures___Line": pd.Series([0.0], dtype="float64"), "Fishing_Lures___Line___Flux": pd.Series([0.0], dtype="float64"), "Cups": pd.Series([0.0], dtype="float64"), "Cups___Flux": pd.Series([0.0], dtype="float64"), "Plastic_Utensils": pd.Series([0.0], dtype="float64"), "Plastic_Utensils___Flux": pd.Series([0.0], dtype="float64"), "Straws": pd.Series([0.0], dtype="float64"), "Straws___Flux": pd.Series([0.0], dtype="float64"), "Balloons_Mylar": pd.Series([0.0], dtype="float64"), "Balloons_Mylar___Flux": pd.Series([0.0], dtype="float64"), "Personal_Care_Products": pd.Series([0.0], dtype="float64"), "Personal_Care_Products___Flux": pd.Series([0.0], dtype="float64"), "Plastic_Other": pd.Series([0.0], dtype="float64"), "Plastic_Other___Flux": pd.Series([0.0], dtype="float64"), "Metal": pd.Series([0.0], dtype="float64"), "Metal___Flux": pd.Series([0.0], dtype="float64"), "Aluminum_Tin_Cans": pd.Series([0.0], dtype="float64"), "Aluminum_Tin_Cans___Flux": pd.Series([0.0], dtype="float64"), "Aerosol_Cans": pd.Series([0.0], dtype="float64"), "Aerosol_Cans___Flux": pd.Series([0.0], dtype="float64"), "Metal_Fragments": pd.Series([0.0], dtype="float64"), "Metal_Fragments___Flux": pd.Series([0.0], dtype="float64"), "Metal_Other": pd.Series([0.0], dtype="float64"), "Metal_Other___Flux": pd.Series([0.0], dtype="float64"), "Glass": pd.Series([0.0], dtype="float64"), "Glass___Flux": pd.Series([0.0], dtype="float64"), "Glass_Beverage_Bottles": pd.Series([0.0], dtype="float64"), "Glass_Beverage_Bottles___Flux": pd.Series([0.0], dtype="float64"), "Jars": pd.Series([0.0], dtype="float64"), "Jars___Flux": pd.Series([0.0], dtype="float64"), "Glass_Fragments": pd.Series([0.0], dtype="float64"), "Glass_Fragments___Flux": pd.Series([0.0], dtype="float64"), "Glass_Other": pd.Series([0.0], dtype="float64"), "Glass_Other___Flux": pd.Series([0.0], dtype="float64"), "Rubber": pd.Series([0.0], dtype="float64"), "Rubber___Flux": pd.Series([0.0], dtype="float64"), "Flip_Flops": pd.Series([0.0], dtype="float64"), "Flip_Flops___Flux": pd.Series([0.0], dtype="float64"), "Rubber_Gloves": pd.Series([0.0], dtype="float64"), "Rubber_Gloves___Flux": pd.Series([0.0], dtype="float64"), "Tires": pd.Series([0.0], dtype="float64"), "Tires___Flux": pd.Series([0.0], dtype="float64"), "Balloons_Latex": pd.Series([0.0], dtype="float64"), "Balloons_Latex___Flux": pd.Series([0.0], dtype="float64"), "Rubber_Fragments": pd.Series([0.0], dtype="float64"), "Rubber_Fragments___Flux": pd.Series([0.0], dtype="float64"), "Rubber_Other": pd.Series(["example_value"], dtype="object"), "Rubber_Other___Flux": pd.Series([0.0], dtype="float64"), "Processed_Lumber": pd.Series([0.0], dtype="float64"), "Processed_Lumber___Flux": pd.Series([0.0], dtype="float64"), "Cardboard_Cartons": pd.Series([0.0], dtype="float64"), "Cardboard_Cartons___Flux": pd.Series([0.0], dtype="float64"), "Paper_and_Cardboard": pd.Series([0.0], dtype="float64"), "Paper_and_Cardboard___Flux": pd.Series([0.0], dtype="float64"), "Paper_Bags": pd.Series([0.0], dtype="float64"), "Paper_Bags___Flux": pd.Series([0.0], dtype="float64"), "Lumber_Building_Material": pd.Series([0.0], dtype="float64"), "Lumber_Building_Material___Flux": pd.Series([0.0], dtype="float64"), "Processed_Lumber_Other": pd.Series([0.0], dtype="float64"), "Processed_Lumber_Other___Flux": pd.Series([0.0], dtype="float64"), "Cloth_Fabric": pd.Series([0.0], dtype="float64"), "Cloth_Fabric___Flux": pd.Series([0.0], dtype="float64"), "Clothing___Shoes": pd.Series([0.0], dtype="float64"), "Clothing___Shoes___Flux": pd.Series([0.0], dtype="float64"), "Gloves__non_rubber_": pd.Series([0.0], dtype="float64"), "Gloves__non_rubber____Flux": pd.Series([0.0], dtype="float64"), "Towels_Rags": pd.Series([0.0], dtype="float64"), "Towels_Rags___Flux": pd.Series([0.0], dtype="float64"), "Rope_Net_Pieces__non_nylon_": pd.Series([0.0], dtype="float64"), "Rope_Net_Pieces__non_nylon____F": pd.Series([0.0], dtype="float64"), "Fabric_Pieces": pd.Series([0.0], dtype="float64"), "Fabric_Pieces___Flux": pd.Series([0.0], dtype="float64"), "Cloth_Fabric_Other": pd.Series([0.0], dtype="float64"), "Cloth_Fabric_Other___Flux": pd.Series([0.0], dtype="float64"), "Unclassified": pd.Series([0.0], dtype="float64"), "Unclassified___Flux": pd.Series([0.0], dtype="float64"), "Total_Debris___Flux": pd.Series(["example_value"], dtype="object"), "Debris_Description": pd.Series(["example_value"], dtype="object")})
output_sample = np.array([0.0])
try:
    log_server.enable_telemetry(INSTRUMENTATION_KEY)
    log_server.set_verbosity('INFO')
    logger = logging.getLogger('azureml.automl.core.scoring_script')
except:
    pass


def init():
    global model
    # This name is model.id of model that we want to deploy deserialize the model file back
    # into a sklearn model
    model_path = os.path.join(os.getenv('AZUREML_MODEL_DIR'), 'model.pkl')
    path = os.path.normpath(model_path)
    path_split = path.split(os.sep)
    log_server.update_custom_dimensions({'model_name': path_split[-3], 'model_version': path_split[-2]})
    try:
        logger.info("Loading model from path.")
        model = joblib.load(model_path)
        logger.info("Loading successful.")
    except Exception as e:
        logging_utilities.log_traceback(e, logger)
        raise


@input_schema('data', PandasParameterType(input_sample))
@output_schema(NumpyParameterType(output_sample))
def run(data):
    try:
        result = model.predict(data)
        return json.dumps({"result": result.tolist()})
    except Exception as e:
        result = str(e)
        return json.dumps({"error": result})
